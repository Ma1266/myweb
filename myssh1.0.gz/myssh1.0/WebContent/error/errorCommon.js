$(document).ready(function() {
	jump(1135);
});
//
