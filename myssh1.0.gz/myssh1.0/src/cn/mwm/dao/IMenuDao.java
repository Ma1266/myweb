package cn.mwm.dao;

import java.util.List;

import cn.mwm.model.TFunction;


public interface IMenuDao extends IbaseDao<TFunction> {

}
