package cn.mwm.dao.impl;

import cn.mwm.dao.ILogDao;

public class LogDaoImpl<TLog> extends BaseDaoImpl<TLog> implements ILogDao<TLog> {

	
	
}
