package cn.mwm.dao;


import cn.mwm.vo.User;

@SuppressWarnings("hiding")
public interface IUserDao<User> extends IbaseDao<User> {
	
}
