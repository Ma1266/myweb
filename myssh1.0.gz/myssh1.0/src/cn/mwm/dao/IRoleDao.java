package cn.mwm.dao;

import cn.mwm.dao.IbaseDao;

public interface IRoleDao<TRole> extends IbaseDao<TRole> {

}
