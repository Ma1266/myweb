package cn.mwm.dao;

public interface ILogDao<TLog> extends IbaseDao<TLog> {

}
