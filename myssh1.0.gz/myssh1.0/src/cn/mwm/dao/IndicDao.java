package cn.mwm.dao;

import java.util.List;

import cn.mwm.model.TDictionary;

public interface IndicDao<TDictionary> extends IbaseDao<TDictionary> {
}
