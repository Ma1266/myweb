package cn.mwm.action;

public class SystemAction extends BaseAction {

	
	
	
	public String goMainPage() {
		return MAIN;
	}
}
