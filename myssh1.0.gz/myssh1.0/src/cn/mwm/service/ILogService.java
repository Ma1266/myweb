package cn.mwm.service;

public interface ILogService {

	
	
	public void saveLog();
}
