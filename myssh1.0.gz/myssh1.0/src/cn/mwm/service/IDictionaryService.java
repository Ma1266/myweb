package cn.mwm.service;

import java.util.List;

import cn.mwm.model.TDictionary;

public interface IDictionaryService {

	List<TDictionary> findAllDic();
}
